package juego;

import java.awt.Image;

public class Pep {
	double x;
	double y;
	boolean direccion;
	Image Imagenizq;
	Image Imagender;
	double escala;
	double velocidad;
	
	public Pep(double x, double y) {
		this.x = x;
		this.y = y;
		direccion = false;
		this.escala = 0;
		this.velocidad = 1;
		this.Imagender = entorno.Herramientas.cargarImagen("caballero-.jpg");
		this.Imagenizq = entorno.Herramientas.cargarImagen("caballero-.jpg");
		
		
	}
	

}
