package juego;

import java.awt.Image;

public class Tortuga {
	double x;
	double y;
	double escala;
	double velocidad;
	Image ImagenIzq;
	Image Imagender;
	
	public Tortuga(double x,double y) {
		this.x = x;
		this.y = y;
		this.escala = 0;
		this.velocidad = 1;
		this.Imagender = entorno.Herramientas.cargarImagen("Tortuga.jpg");
		this.ImagenIzq = entorno.Herramientas.cargarImagen("Tortuga.jpg");
	}
	

}
